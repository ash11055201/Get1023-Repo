package view;

import java.util.ArrayList;

public interface CollectionsDemo {
	public static void main(String[] args) {
		Iterable<Integer> nums = new ArrayList<Integer>();
		
	}
}
