package model;

public enum Qualification {
	Matric,Intermediate,Graduate,Master;
}
